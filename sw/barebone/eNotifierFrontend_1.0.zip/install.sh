echo " -> Check and Stop service"
sudo service apache2 stop
sudo rm -rf /usr/share/iz2k/eNotifierFrontend
echo " -> Install component"
sudo mkdir /usr/share/iz2k/eNotifierFrontend
sudo cp version.txt /usr/share/iz2k/eNotifierFrontend/
sudo cp -r public /usr/share/iz2k/eNotifierFrontend/
echo " -> Start Service"
sudo service apache2 start
echo "Done"
