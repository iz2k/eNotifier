#!/usr/bin/python
# -*- coding:utf-8 -*-
import sys
import os
picdir = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), 'pic')
libdir = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), 'lib')
if os.path.exists(libdir):
    sys.path.append(libdir)

import logging
from waveshare_epd import epd7in5bc
import time
from PIL import Image,ImageDraw,ImageFont
import traceback

logging.basicConfig(level=logging.DEBUG)

opt=1
print('opt:' + str(opt))

try:
    logging.info("epd7in5bc Demo")
    font24 = ImageFont.truetype(os.path.join(picdir, 'Font.ttc'), 24)
    font18 = ImageFont.truetype(os.path.join(picdir, 'Font.ttc'), 18)
    
    epd = epd7in5bc.EPD()
    epd.init()
    if(opt==1):
        logging.info("Init and Clear")
        epd.init()
        epd.Clear()
        logging.info("Done!")

    if (opt == 2):
        logging.info("Read bmp file")
        #HBlackimage = Image.open(os.path.join(picdir, '7in5b-b.bmp'))
        #HRYimage = Image.open(os.path.join(picdir, '7in5b-r.bmp'))
        HBlackimage = Image.open(os.path.join(picdir, '7in5c-b.bmp'))
        HRYimage = Image.open(os.path.join(picdir, '7in5c-r.bmp'))
        epd.display(epd.getbuffer(HBlackimage), epd.getbuffer(HRYimage))

    if (opt==3):
        # Drawing on the Horizontal image
        logging.info("Drawing on the Horizontal image...")
        HBlackimage = Image.new('1', (epd.width, epd.height), 255)  # 298*126
        HRYimage = Image.new('1', (epd.width, epd.height), 255)  # 298*126  ryimage: red or yellow image
        drawblack = ImageDraw.Draw(HBlackimage)
        drawry = ImageDraw.Draw(HRYimage)
        drawblack.text((10, 0), 'hello world', font=font24, fill=0)
        drawry.text((10, 20), '7.5inch e-Paper bc', font=font24, fill=0)
        epd.display(epd.getbuffer(HBlackimage), epd.getbuffer(HRYimage))

    if (opt==4):
        # Drawing on the Horizontal image
        logging.info("Drawing on the Horizontal image...")
        HBlackimage = Image.new('1', (epd.width, epd.height), 255)  # 298*126
        HRYimage = Image.new('1', (epd.width, epd.height), 255)  # 298*126  ryimage: red or yellow image
        drawblack = ImageDraw.Draw(HBlackimage)
        drawry = ImageDraw.Draw(HRYimage)
        drawblack.rectangle((20, 50, 70, 100), outline=0)
        drawry.rectangle((80, 50, 130, 100), fill=0)
        epd.display(epd.getbuffer(HBlackimage), epd.getbuffer(HRYimage))

    logging.info("Goto Sleep...")
    epd.sleep()
        
except IOError as e:
    logging.info(e)
    
except KeyboardInterrupt:    
    logging.info("ctrl + c:")
    epd7in5bc.epdconfig.module_exit()
    exit()
